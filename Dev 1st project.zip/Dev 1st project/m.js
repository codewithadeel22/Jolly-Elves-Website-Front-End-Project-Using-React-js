function ca(){
    let computer=document.getElementById('com').value;
    let chemistry=document.getElementById('ch').value;
    let physics=document.getElementById('ph').value;
    let urdu=document.getElementById('ur').value;
    let grade="";
    let total=parseFloat(computer)+parseFloat(chemistry)+parseFloat(physics)+parseFloat(urdu);
    let perc=(total/400)*100;
    if (perc <= 100 && perc >=80) {
        grade="A"
    }
    else if (perc <=79 && perc >=60) {
        grade="B"
    }
    else if (perc <=59 && perc >=40) {
        grade="C"
    }
    else{
        grade="D"
    }
    document.getElementById('showdata').innerHTML=`Out of 400 Marks your total marks is ${total} your grade is ${grade} Your marks percentage is ${perc}%`
}if (perc >=39 && perc >=0) {
    document.getElementById('showdata')
.innerHTML=` Out Of 400 Your total is ${total} and your percentage is ${perc}%
.<br> And your Grade Is ${grade}.You Are Pass.`
}
else{
    document.getElementById('showdata')
    .innerHTML=` Out Of 400 Your total is ${total} and your percentage is ${perc}%
    .<br> And your Grade Is ${grade}.You Are Fail.`
}
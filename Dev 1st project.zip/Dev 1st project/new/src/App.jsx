import React from 'react'
import { useState,useEffect } from 'react'
import Home from './assets/Home'
import Res from './assets/Res'
import Com from './assets/Com'
import Ins from './assets/Ins'
import Logo from './assets/p1.png'
import Logo1 from './assets/p2.png'
import Logo2 from './assets/n.png'
import Logo3 from './assets/dark.png'

import CardSlider from './assets/CardSlider'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom'

function App() {
  
  const [togle,settogle]=useState(false)
const toggleBulb =()=>{
settogle((prevtogle) => !prevtogle);
}
useEffect(() => {
  const intervalId = setInterval(toggleBulb, 2000);
  return () => clearInterval(intervalId);
}, []);
  return (
<BrowserRouter  className='main-dev'>
<header className='item' >
<p className='p'>JOLLY ELVES CERTIFIED LIGHTING & ORNAMENTATION SPECIALISTS</p>



</header>
<h2> {togle ? <img src={Logo3} className='p22'/> : <img src={Logo2} className='p22'/>}</h2><span><h3 className='qout'>GET A QUOTE</h3></span>
<main className='home'>
<Link to='/Home' className='none1'>HOME</Link>
<Link to='/Res' className='none'>RESEDENTIAL</Link>
<Link to='/Com' className='none'>COMMERCIAL</Link>
<Link to='/Ins' className='none'>INSPIRATION</Link>

<input type='email' className='inpt' placeholder='&#xf232; 123 4567 890   &#xf0e0;mail@yourmail.com '/>



</main>
<header>

<img src={Logo} className='p1'/>
</header>
<Routes>
<Route path='/Home' element={<Home/>}/>
<Route path='/Res' element={<Res/>}/>
<Route path='/Com' element={<Com/>}/>
<Route path='/Ins' element={<Ins/>}/>
<Route path='/CardSlider' element={<CardSlider/>}/>
</Routes>
</BrowserRouter>
  )
}

export default App
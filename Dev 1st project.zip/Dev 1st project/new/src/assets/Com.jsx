import React from 'react'

function Com() {
  return (
    <div>Com</div>
  )
}

export default Com
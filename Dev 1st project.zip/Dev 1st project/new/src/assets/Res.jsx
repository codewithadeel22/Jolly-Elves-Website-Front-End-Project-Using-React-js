import React from 'react'

function Res() {
  return (
    <div>Res</div>
  )
}

export default Res
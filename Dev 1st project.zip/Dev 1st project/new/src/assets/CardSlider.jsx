import React, { Component } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Logo9 from '../assets/star.png'
import Logo10 from '../assets/first.png'
import Logo11 from '../assets/second.png'
import Logo12 from '../assets/cv2.jpg'
import Logo13 from '../assets/cv.jpg'
import Logo14 from '../assets/cv3.jpg'
export default class PreviousNextMethods extends Component {
  constructor(props) {
    super(props);
    this.next = this.next.bind(this);
    this.previous = this.previous.bind(this);
  }
  next() {
    this.slider.slickNext();
  }
  previous() {
    this.slider.slickPrev();
  }
  render() {
    const settings = {
      dots: false,
      infinite: false,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1
    };
    return (
      <div>
      
        <Slider ref={c => (this.slider = c)} {...settings}>
       
       
       
          <div key={1}>
          <div className="All-item">
          <div className='box1'>
          <div className='box11'>
          <img src={Logo12} className='pasport-img'/>
          <div className='deb'>
          <h3>DEBBIE LIM</h3>
          <p className='abc'>ABC COMPANY</p>
          </div>
          </div>
          <p className='short-p'>It is a long established fact that a <br/>
          reader will be distracted by the readable<br/>
           content of a page when looking at its layout. <br/>
           The point of using Lorem Ipsum is that it has <br/> 
           normal distribution of letters, as opposed to <br/>
            here, content here', making it look like read.</p>
            <div className='star'>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            </div>
            
          </div>
          <div className='box1'>
          <div className='box11'>
          <img src={Logo13} className='pasport-img'/>
          <div className='deb'>
          <h3>DEBBIE LIM</h3>
          <p className='abc'>ABC COMPANY</p>
          </div>
          </div>
          <p className='short-p'>It is a long established fact that a <br/>
          reader will be distracted by the readable<br/>
           content of a page when looking at its layout. <br/>
           The point of using Lorem Ipsum is that it has <br/> 
           normal distribution of letters, as opposed to <br/>
            here, content here', making it look like read.</p>
            <div className='star'>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            </div>
            
          </div>
          <div className='box1'>
          <div className='box11'>
          <img src={Logo14} className='pasport-img'/>
          <div className='deb'>
          <h3>DEBBIE LIM</h3>
          <p className='abc'>ABC COMPANY</p>
          </div>
          </div>
          <p className='short-p'>It is a long established fact that a <br/>
          reader will be distracted by the readable<br/>
           content of a page when looking at its layout. <br/>
           The point of using Lorem Ipsum is that it has <br/> 
           normal distribution of letters, as opposed to <br/>
            here, content here', making it look like read.</p>
            <div className='star'>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            </div>
            
          </div>
          </div>
         
          </div>
         
          <div key={2}>
          <div className="All-item">
          <div className='box1'>
          
          <div className='box11'>
          <img src={Logo13} className='pasport-img'/>
          <div className='deb'>
          <h3>DEBBIE LIM</h3>
          <p className='abc'>ABC COMPANY</p>
          </div>
          </div>
          <p className='short-p'>It is a long established fact that a <br/>
          reader will be distracted by the readable<br/>
           content of a page when looking at its layout. <br/>
           The point of using Lorem Ipsum is that it has <br/> 
           normal distribution of letters, as opposed to <br/>
            here, content here', making it look like read.</p>
            <div className='star'>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            </div>
            </div>
            <div className='box3'>
            <div className='box11'>
            <img src={Logo12} className='pasport-img'/>
            <div className='deb'>
            <h3>DEBBIE LIM</h3>
            <p className='abc'>ABC COMPANY</p>
            </div>
            </div>
            <p className='short-p'>It is a long established fact that a <br/>
            reader will be distracted by the readable<br/>
             content of a page when looking at its layout. <br/>
             The point of using Lorem Ipsum is that it has <br/> 
             normal distribution of letters, as opposed to <br/>
              here, content here', making it look like read.</p>
              <div className='star'>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              </div>
              
            </div>
            <div className='box1'>
            <div className='box11'>
            <img src={Logo14} className='pasport-img'/>
            <div className='deb'>
            <h3>DEBBIE LIM</h3>
            <p className='abc'>ABC COMPANY</p>
            </div>
            </div>
            <p className='short-p'>It is a long established fact that a <br/>
            reader will be distracted by the readable<br/>
             content of a page when looking at its layout. <br/>
             The point of using Lorem Ipsum is that it has <br/> 
             normal distribution of letters, as opposed to <br/>
              here, content here', making it look like read.</p>
              <div className='star'>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              </div>
              
            </div>
          </div>
          </div>
          <div key={3} >
          <div className="All-item">
          <div className='box1'>
          <div className='box11'>
          <img src={Logo14} className='pasport-img'/>
          <div className='deb'>
          <h3>DEBBIE LIM</h3>
          <p className='abc'>ABC COMPANY</p>
          </div>
          </div>
          <p className='short-p'>It is a long established fact that a <br/>
          reader will be distracted by the readable<br/>
           content of a page when looking at its layout. <br/>
           The point of using Lorem Ipsum is that it has <br/> 
           normal distribution of letters, as opposed to <br/>
            here, content here', making it look like read.</p>
            <div className='star'>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            <img src={Logo9} className='stars'/>
            </div>
            </div>
            <div className='box1'>
            <div className='box11'>
            <img src={Logo13} className='pasport-img'/>
            <div className='deb'>
            <h3>DEBBIE LIM</h3>
            <p className='abc'>ABC COMPANY</p>
            </div>
            </div>
            <p className='short-p'>It is a long established fact that a <br/>
            reader will be distracted by the readable<br/>
             content of a page when looking at its layout. <br/>
             The point of using Lorem Ipsum is that it has <br/> 
             normal distribution of letters, as opposed to <br/>
              here, content here', making it look like read.</p>
              <div className='star'>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              </div>
              
            </div>
            <div className='box1'>
            <div className='box11'>
            <img src={Logo12} className='pasport-img'/>
            <div className='deb'>
            <h3>DEBBIE LIM</h3>
            <p className='abc'>ABC COMPANY</p>
            </div>
            </div>
            <p className='short-p'>It is a long established fact that a <br/>
            reader will be distracted by the readable<br/>
             content of a page when looking at its layout. <br/>
             The point of using Lorem Ipsum is that it has <br/> 
             normal distribution of letters, as opposed to <br/>
              here, content here', making it look like read.</p>
              <div className='star'>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              <img src={Logo9} className='stars'/>
              </div>
              
            </div>
          </div>
         </div>
        </Slider>
        <div className="button-1">
        
        <div style={{ textAlign: "center" }} >
       
        <button className="button" onClick={this.previous}>
          <img src={Logo10} className="final-pic"/>
        </button>
        <button className="button1" onClick={this.next} >
        <img src={Logo11} className="final-pic"/>
        </button>
        
       
        </div>
        </div>
      </div>
    );
  }
}
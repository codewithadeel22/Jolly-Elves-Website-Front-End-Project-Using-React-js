import React from 'react'
import { useState,useEffect } from 'react'
import Logo5 from '../assets/arow.png'
import Logo6 from '../assets/tree.jpg'
import Logo7 from '../assets/hom.jpg'
import Logo8 from '../assets/t.png'
import Logo9 from '../assets/star.png'
import Logo10 from '../assets/first.png'
import Logo11 from '../assets/second.png'
import Logo12 from '../assets/whats.png'
import Logo13 from '../assets/maill.png'
import Logo14 from '../assets/clipa.png'
import Logo15 from '../assets/p1.png'
import Logo16 from '../assets/p2.png'
import Logo3 from '../assets/dark.png'
import CardSlider from './CardSlider'
function Home() {
   
  const [togle,settogle]=useState(false)
const toggleBulb =()=>{
settogle((prevtogle) => !prevtogle);
}
useEffect(() => {
  const intervalId = setInterval(toggleBulb, 2000);
  return () => clearInterval(intervalId);
}, []);
  return (
    <div className='main-dev'>
    <div className='h-main'>
    <div className='h-main1'>
    
    <h2 className='h2'>WE ARE JOLLY ELVES</h2>
    <p className='para'>
    jolly elves is a compnay that specializes in professional lighting and <br/>
    custom installation for clients with commercial or residential properties.<br/>
    We pride ourselves on breing a trustworthy,outgoing,and dependable<br/>
    Company in the Los Angeles and orange County California area.<br/>
    <br/>
    We Owe Our Success to our grifted design teams who start the process by<br/>
    designing the perfect aesthetic specifically for each client's needs.Then,<br/>
    Our telented installation crews get to work,bringing those design to life <br/>
    with your property as the canvas.And let's not forget about our mainte<br/>
    nance crews,who keep the displays in the top-shape year round.
    </p>
    
    <img src={Logo5} className='arow1'/><span className='read'>Read More</span>
    
    </div>
    <div>
    <img src={Logo6} className='tree'/>
    </div>
    <div>
    <img src={Logo7} className='hom'/>
    </div>
    </div>
    <div className='main-tc'>
    
    <div className="t-c">
    <div className='pm-1'>
    <div className='my-1'>
    <h3 className='des1'>01.</h3>
    <h3 className='cl' >DESIGN</h3>
    
    </div>
    <div className='words'>
    Our expert design team <br/>will guid you through your option to bting your ideas
    to life !
    </div>
    </div>
    <div className='pm-1'>
    <div className='my-1'>
    <h3 className='des1'>02.</h3>
    <h3 className='cl'>INSTALLATION</h3>
    
    </div>
    <div className='words'>
    Our jolly elves are now ready to take your design and transform your property into a holiday dream.
    </div>
    </div>
    <div className='pm-1'>
    <div className='my-1'>
    <h3 className='des1'>04.</h3>
    <h3 className='cl'>REMOVEL</h3>
    
    </div>
    <div className='words'>
    Starting january we will schedule the removel of the decore.Unlike the grinch we will be back again next year to brighten up your home.
    </div>
    </div>
    </div>
    <div className="t-c1">
    <div className='my-2'>
    <div className='my-3'>
    <h3 className='pm2'>03.</h3> 
    <h3 className='cl'>MENTENANCE</h3>
    </div>
    <div className='words1'>
    Starting january we will schedule the removel of the decore.Unlike the grinch we will be back again next year to brighten up your home.
    </div>
    </div>
    <div className='my-4'>
<div className='my-5'>
<h3  className='pmm'>05.</h3>
<h3 className='cl1'>STORAGE</h3>
</div>

<div className='word2'>
All our material maintained,lablled,and stored by client,so we are ahead of the game and prepared for the coming season.
</div>
    </div>
    
    </div>
    <div className='circle'>
    
    <span className='circle-1'></span>
    <span className='circle-2'></span>
    <span className='circle-3'></span>
    <span className='circle-4'></span>
    <span className='circle-5'></span>
   
    </div>
    <h3 className='our'>OUR START TO FINISH PROCESS</h3>
    <div className='red'>
    <div className='plus1'>
    <h1 className='plus'>35<sup>+</sup></h1>
    <h4 className='year'>YEARS OF <br/>ELECTRICAL<br/>EXPERIENCE</h4>
    <img src='https://img.icons8.com/?size=48&id=Xy10Jcu1L2Su&format=png' className='icn1'/>
    <img src='https://img.icons8.com/?size=48&id=uLWV5A9vXIPu&format=png' className='icn'/>
    <img src='https://img.icons8.com/?size=48&id=bUGbDbW2XLqs&format=png' className='icn'/>
    </div>
    <div className='gur'>
    <h3 className='whit'>HOW WE GUARANTEE SUCCESS</h3>
    <div className='safe1'>
    
    <div className='safe'>
    <ul>
    <h3><li>SAFETY</li></h3>
    <h1 className='border'></h1>
    <p className='para1'>The safty our team members<br/>
     and clients is our main pirorty.<br/>
     we provide top notch training to<br/>
      our techinician on all equipment <br/>
     needed to complete your install.<br/>
      with an impeccable safety track<br/>
      record and over 35 year of electri-<br/>
      cal experience</p>
    </ul>
    </div>
    <div className='quality'>
    <ul>
    <h3><li>QUALITY</li></h3>
    <h1 className='border'></h1>
    <p className='para1'>Jolly elves ensures that our work<br/>
    and materials are of the highest<br/>
    quality.Form the beginning of<br/>
    the design process to the removal<br/>
    and sotrage,we provide top rated<br/>
    services to give our clients a<br/>
    stress-free holiday</p>
    </ul>
    </div>
    <div className='service'>
    <ul>
    <h3><li>SERVICE</li></h3>
    <h1 className='border'></h1>
    <p className='para1'>We pride ourselves on being 100%<br/>
    committed to our client;s holiday<br/>
    decore needs.personalizes service<br/>
    from the first call to the removel.<br/>
    we are to develop relation-<br/>
    ships of trust with our clients to<br/>
    keep them coming back year after<br/>
    year.</p>
    </ul>
    </div>
    </div>
    </div>
 
    </div>
    <div className='pic-img'>

    <div className='pic5'>
    <h3 className='bg'>GET A FREE IN-PERSON<br/>
    CONSULTATION FOR INTERIOR<br/>
    DECORE AND COMMERCIAL<br/>
    PROPERITIES ONLY</h3>
    <p className='bg1'>Just leave a request below</p>
    <div className='btn-dev'>
    <input type='text' placeholder='Your Phone Number' className='inp'/>
    <button className='btn'>Call Me Back</button>
    </div>
    
    </div>
    <img src={Logo8} className='img3'/>
    </div>
    </div>
   <div className='main3'>
   <h3 className='client'>WHAT OUR CLIENT SAYS</h3>
   <CardSlider className='Carasole'/>
  
  
  









   </div>
   <p className='red4'>dasd</p>
   <div className='last'>
   <div className='pic-last'>
   <img src='https://img.icons8.com/?size=48&id=Xy10Jcu1L2Su&format=png' className='icn2'/>
   <img src='https://img.icons8.com/?size=48&id=uLWV5A9vXIPu&format=png' className='icn2'/>
   <img src='https://img.icons8.com/?size=48&id=bUGbDbW2XLqs&format=png' className='icn2'/>
   </div>
   <div className='para-last'>
   <p className='last-one1'>Jolly elves is a company that specializes in professional lighting and
   custom installation for client with commercial or residential properties.
   we pride ourselves on being trustworthy,outgoing,and dependable
   company in the los Angeles and orange County California area.</p>
   <p className='last-one1'>Wr owe our Success to our grifted design teams who start the process by
   designing the perfect aesthetic specifically for each client needs.then,
   our talented installation crews get to work,bringing those designs to life
   with your property as the canvas.and let's not forget about our
   maintenance crews,who keep the displaysin top-shape year</p>
   </div>
   <div className='quik-link'>
   <h3 className='last-2'>QUICK LINKS</h3>
   <p className='last-one'>Home</p>
   <p className='last-one'>Residential</p>
   <p className='last-one'>Commercial</p>
   <p className='last-one'>Inspiration</p>
   </div>
   <div className='contact-us'>
   <h3 className='last-2'>Contact Us</h3>
   <div className='logo-last'>
   <img src={Logo12} className='small'/>
   <p className='last-one'>111 222 333</p>
   </div>
   <div className='logo-last1'>
   <img src={Logo13} className='small'/>
   <p className='last-one'>yourmail@gmail.com</p>
   </div>
   <img src={Logo14} className='clipa'/>
   </div>
  
   </div>
   <img src={Logo15} className='last-p'/>
   <p className='copy'>COPYRIGHT @ 2023 JOLLY ELVES-ALL RIGHT RESERVED</p>
   <div className='cc'>
   </div>
   
   {togle ? <img src={Logo16} className='last-p1'/> : <img src={Logo3} className='last-p1'/>}
   <h3  className='last-d'>Get A QUOTE</h3>
  
    </div>
  )
}

export default Home
import React from 'react'

function Ins() {
  return (
    <div>Ins</div>
  )
}

export default Ins